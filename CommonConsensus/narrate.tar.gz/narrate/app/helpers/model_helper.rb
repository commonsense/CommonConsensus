module ModelHelper
  $site = "http://18.85.16.150:3000/Goals/"
end
