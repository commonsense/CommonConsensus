class Bad < ActiveRecord::Base
end
