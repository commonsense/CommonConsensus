class TempGuesses < ActiveRecord::Base
end
