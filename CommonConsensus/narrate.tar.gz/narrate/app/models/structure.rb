class Structure < ActiveRecord::Base
end
