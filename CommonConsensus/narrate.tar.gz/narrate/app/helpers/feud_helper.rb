module FeudHelper
end
