class Guess < ActiveRecord::Base
end
