class TempUsers < ActiveRecord::Base
end
