class Feedback < ActiveRecord::Base
end
