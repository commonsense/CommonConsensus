class ModelController < ApplicationController

  def User
  end
end
