class Quotes < ActiveRecord::Base
end
