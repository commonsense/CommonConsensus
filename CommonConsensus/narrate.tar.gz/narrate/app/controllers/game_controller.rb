class GameController < ApplicationController
end
